DAE programming for artists 1 exam project
=
SPACE TYPER

Author:
-
Lennert De Kegel

requirements:
-
 - Python 3.12.3
 - Game engine:  dae_progfa_lib 1.1.0

general libreries used:
-
 - math
 - time
 - random
 - winsound
 - pygame
   - mixer_music
