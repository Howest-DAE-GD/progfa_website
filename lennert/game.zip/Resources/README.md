Licences for these resources:
-

- Images:
  - Self designed

- Icons:
  - Self designed

- Music:
  - origin: pixabay.com
  - composer: moodmode
  - name: Game 8-Bit On
  - licence: free commercial, no copyright
  - usage: background

- Fonts:
  - mono
    - family: mono.otf
    - origin: 
  - normal
    - family:
    - origin:
  - strong
    - family:
    - origin: